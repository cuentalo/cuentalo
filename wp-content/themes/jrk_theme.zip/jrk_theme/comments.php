<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains comments and the comment form.
 *
 * @package WordPress
 * @subpackage Twenty_Thirteen
 * @since Twenty Thirteen 1.0
 */
 
/*
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() )
    return;
?>
 
<div id="comments" class="comments-area form-group">
 
    <?php if ( have_comments() ) : ?>
        <p class="comments-title">

            <?php
                echo get_comments_number();
            ?>
            <span>Comentarios</span>
        </p>
 
        <ol class="comment-list">
            <?php
                wp_list_comments( array(
                    'style'       => 'ol',
                    'short_ping'  => true,
                    'avatar_size' => 32,
                    'reply_text'  => 'Responder',
                ) );
            ?>
        </ol><!-- .comment-list -->
 
        <?php
            // Are there comments to navigate through?
            if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
        ?>
        <nav class="navigation comment-navigation" role="navigation">
            <h1 class="screen-reader-text section-heading"><?php _e( 'Comment navigation', 'perla' ); ?></h1>
            <div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'perla' ) ); ?></div>
            <div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'perla' ) ); ?></div>
        </nav><!-- .comment-navigation -->
        <?php endif; // Check for comment navigation ?>
 
        <?php if ( ! comments_open() && get_comments_number() ) : ?>
        <p class="no-comments"><?php _e( 'Comments are closed.' , 'perla' ); ?></p>
        <?php endif; ?>
 
    <?php endif; // have_comments() ?>
 
    <?php 
            //Mostrar formulario de comentarios
            comment_form(array(
                'title_reply' => __('¿Y tú qué opinas?', 'perla'), //Cambiar título
                'label_submit' => __('Publicar opinión', 'perla'), //Cambiar texto de botón
                'comment_field' => '<textarea id="comment" class="form-control" name="comment" cols="45" rows="3" aria-required="true" placeholder="' . __('Escribe tu opinión...', 'perla') . '"></textarea>', //Borrar párrafo y label del textarea
                'comment_notes_before' => '',
            ));
 ?>
 
</div><!-- #comments -->