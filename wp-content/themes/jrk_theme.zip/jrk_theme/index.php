<?php get_header(); ?>
<section class="slider-home">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-xs-12 col-sm-12">
                <div class="slider-content">
                     <h1>Graffiti Expresión de un grupo social</h1>
                     <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Maxime dolorum fugiat tenetur, consectetur quos similique vel ea? Itaque nostrum et quos ducimus?</p>
                     <div class="datos-slider">
                        <ul>                            
                            <li><a href="#" class="btn-ir">Ver historia</a></li>
                            <li><span>Por: </span><a href="#" class="link-blanco">grupo graff caribe</a></li>
                        </ul> 
                     </div>
                </div>
            </div>

        </div>
    </div>  
</section>
<section class="home-contenido time-line py-5" id="a"> 
  <div class="container">
      <h2 class="title-h2 line-title pb-2 mt-5">Acerca de </h2>
      <article class="page">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum reiciendis aliquam tempore inventore, earum asperiores ab sit sequi quos tenetur porro eaque sint assumenda nostrum amet quae aperiam! Expedita, vitae!</p>
        <p>Nam nec mi sed urna viverra feugiat eget ut ligula. Morbi iaculis nec nibh id fringilla. Nam sit amet tellus mattis sem ultricies feugiat porta vel neque. Praesent eros ligula, venenatis in urna a, pulvinar rutrum libero. Ut ullamcorper lobortis placerat. Nullam scelerisque vel quam in lobortis. Curabitur consequat vel mauris maximus malesuada. Suspendisse facilisis, urna vitae lacinia varius, erat urna venenatis nunc, sed vestibulum ante massa faucibus lectus. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <p>Proin id ligula condimentum, sagittis enim eu, egestas eros. Fusce convallis massa at rutrum aliquet. Mauris ut sagittis nisi. Vestibulum euismod finibus rutrum. Integer sed mi quis arcu vestibulum maximus in eget lectus. Quisque eu erat at ex suscipit ultrices. Sed tristique risus ac ipsum luctus, vitae tristique purus accumsan. Vestibulum elementum nec dui nec tincidunt.</p>
        <p>Maecenas tellus mi, scelerisque a facilisis non, auctor eget est. Aenean nec nulla eget tortor efficitur facilisis. Sed consectetur ultrices hendrerit. Pellentesque lacus lectus, tempor et mollis ut, vulputate vel sapien. Interdum et malesuada fames ac ante ipsum primis in faucibus. Quisque volutpat pretium mauris, eleifend eleifend sem cursus ut. Nunc in turpis justo. Nulla bibendum risus et erat pharetra, eget pharetra ex efficitur. Mauris interdum ante nec fermentum porttitor. Vivamus non tortor augue. Vestibulum quis nulla aliquet, vestibulum nunc a, elementum eros. Mauris finibus faucibus blandit. Praesent nulla nisl, elementum a tellus quis, ullamcorper tempus justo. Etiam sem ex, suscipit non mauris eu, varius rhoncus metus. Donec efficitur lorem eu leo blandit, vitae porta ligula malesuada. Aenean maximus eleifend convallis.</p>
      </article>
  </div> 
</section>
<section class="time-line py-5" id="b">
  <div class="container">
      <h2 class="title-h2 line-title pb-2 mt-5">Actividad Reciente</h2>
      <div class="item-tl my-4 p-3">
          <article>       
              <div class="noticias-actuales">
               <?php if (have_posts()) :  while (have_posts()) : the_post(); ?>
                <div class="row bg-items py-4 px-3 mb-5">
                  <div class="col-md-6">
                      <div class="img-thumb">
                          <?php 
                              if ( has_post_thumbnail() ) { 
                                          the_post_thumbnail( 'full', array( 'class' => 'w-100 h-100') );
                                         }
                           ?>
                           <div class="type-item">
                              <?php the_category() ?>
                           </div>  
                      </div>
                  </div>
                  <div class="col-md-6">
                      <div class="new-home">                          
                          <div class="titulo-entrada"><h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2></div>
                          <div class="texto-post"><?php the_excerpt(); ?></div>
                          <div class="categoria-entrada"><i class="fa fa-tags" aria-hidden="true"></i> <?php the_tags( ' ', ' ', '<br />' ); ?> </div>
                          <div class="line-title my-4"></div>
                          <div class="more-date">
                            <h3 class="pb-2">Información de contacto</h3>
                              <p><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php the_author_meta('user_email'); ?>"><?php the_author_meta('user_email'); ?></a></p>
                              <p><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php the_author_meta('user_url'); ?>"><?php the_author_meta('user_url'); ?></a></p>
                            </div>
                            <div>
                                
                            </div>
                          <div>
                            <a href="<?php the_permalink(); ?>" class="btn-more">ver mas &#8594</a>
                          </div>
                      </div>
                  </div>
                </div> 
                
                <?php endwhile; else: ?>                
              <?php endif; ?>           
             </div>
          </article>
      </div>
  </div> 
</section>
<?php get_footer(); ?>
