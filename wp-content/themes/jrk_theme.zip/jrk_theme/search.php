<?php get_header(); ?>
<?php
	$iscat = 'historia';
	if( !empty( get_query_var( 'categoria' ) ) ){
		if( get_query_var( 'categoria' )=='grupo') {
			$iscat = 'grupo';
		}		
	}
	global $wp_query;
	$count = sizeof( $wp_query->posts );	
 	
	global $current_user;
    //wp_get_currentuserinfo();
    $user = $current_user->user_login;

	global $query_string;
	//$cuser = '?s='.get_search_query().'&post_type=post&autor='.$user;
	$cuser = 'http://cuentalo.org/?s=&post_type=post&autor='.$user;

?>
<div class="portada foto-portada-history">
	<div class="container">
		<div class="portada-content">
		  <?php if ( $iscat == 'historia' ) { ?>
			<h2>Catálogo de Historias</h2>
			<p>Listado de Historias registradas</p>					
			<div class="menu-grupo py-2">
				<a href="http://cuentalo.org/registrar-una-historia/"><i class="fa fa-plus" aria-hidden="true"></i> Registrar una Historia</a>		
				<a href="<?php echo $cuser.'&categoria=historia'; ?>"><i class="fa fa-search" aria-hidden="true"></i> Ver mis Historias</a>	
				<a href="http://cuentalo.org/?s=&post_type=post&categoria=historia"><i class="fa fa-search" aria-hidden="true"></i> Ver Todas las Historias</a>					
				<a href="#"><i class="fa fa-map" aria-hidden="true"></i> Mapa</a>				
			</div>
			<?php if ( $count == 0 ) { ?>
				<h2>No se encontro ningun registro con esos criterios de busqueda</h2>
				<h3>Por favor, intente de nuevo, cambiando los criterios de busqueda</h3>
			<?php         		
		    }else{?>		
				<h5> <?php echo $count; ?> Historias encontradas</h5>
			<?php } ?>
		<?php }else{ ?>
			 <h2>Catálogo de Grupos</h2>
			 <p>Listado de Grupos registrados</p>						 
			 <div class="menu-grupo py-2">				
				<a href="http://cuentalo.org/registrar-una-historia?categoria=grupo"><i class="fa fa-plus" aria-hidden="true"></i> Registrar un Grupo</a>
				<a href="http://cuentalo.org/?s=&post_type=post&categoria=historia"><i class="fa fa-history" aria-hidden="true"></i> Ver todas las Historias</a>
				<a href="#"><i class="fa fa-map" aria-hidden="true"></i> Mapa</a>				
				<a href="<?php echo $cuser.'&categoria=grupo'; ?>"><i class="fa fa-search" aria-hidden="true"></i> Ver mis Grupos</a>	
				<a href="http://cuentalo.org/?s=&post_type=post&categoria=grupo"><i class="fa fa-search" aria-hidden="true"></i> Ver Todos los Grupos</a>	
			 </div>
			<?php if ( $count == 0 ) { ?>
				<h2>No se encontro ningun registro con esos criterios de busqueda</h2>
				<h3>Por favor, intente de nuevo, cambiando los criterios de busqueda</h3>
			 <?php         		
		     }else{?>		
				<h5> <?php echo $count; ?> Grupos encontrados</h5>
			 <?php } ?>						
		<?php } ?>		
		</div>		
	</div>	
</div>
<section class="bg-dark2">
	<div class="container">
		<div class="row" pb-5>			
			<div class="col-md-4">
				<div class="card mt-5" style="width: 100%;">
					<div class="card-body">
						<h5 class="card-title">Busqueda personalizada</h5>	
						<?php get_search_form(); ?>								
					</div>
				</div>
			 </div>
		</div>
	</div>
</section>

<?php if ( $count > 0 ) { ?>
<section class="bg-dark2">
	<div class="container">
		<div class="row pb-5">
			<?php
			if ( $count > 0) { 			
				$the_query = $wp_query;
				//if ( $the_query->have_posts() ) { 
        		while ( $the_query->have_posts() ) {			
           			$the_query->the_post();  	?>
					<div class="col-md-4">
						<div class="card mt-5" style="width: 100%;">
							<div class="img-thumb">
								<?php 
									if ( has_post_thumbnail() ) { 
										the_post_thumbnail( 'full', array( 'class' => 'card-img-top' ) );
									}
								?>
							</div>
							
							<div class="card-body">
								<h5 class="card-title"><a href="<?php the_permalink(); ?>">
									<?php the_title(); ?>
									</a>
								</h5>
								<p class="card-text"><?php the_excerpt(); ?></p>															
								<?php if ( $user == get_the_author_meta('nickname')) { 
									$editar='http://cuentalo.org/registrar-una-historia/?pid='.$post->ID.'&accion=editar';?>
									<a href="<?php echo $editar; ?>"><i class="fa fa-plus" aria-hidden="true"></i> Editar <?php echo $iscat; ?></a>		
								<?php } ?>		
								<?php if ( $iscat == 'grupo' ) { ?>
									<?php 
										$id = $post->ID;
										//Calcular la cantidad de historias del Grupo
										$args = array(
											'category_name' => 'historia',
											'meta_query' => array(array('key' => 'Grupo_historia',
													'value' => $id))
                							);
										$gh = new WP_Query( $args );
										$c_gh = sizeof( $gh->posts );
										if ( $c_gh != 0 ) {
										?>
										<a href="http://cuentalo.org/?s=&post_type=post&categoria=historia&grupo_historia=<?php echo $id; ?>"><i class="fa fa-history" aria-hidden="true"></i> Ver (<?php echo $c_gh; ?>) Historias</a>
									<?php } else {?>
										<i class="fa fa-history" aria-hidden="true"></i> Sin historias	
									<?php }?>
									<?php if ( $user == get_the_author_meta('nickname') ) { ?>
										<a href="http://cuentalo.org/registrar-una-historia/?grupo_his=<?php echo $id; ?>"><i class="fa fa-plus" aria-hidden="true"></i> Historia</a>		
									<?php } ?>
								
								<?php } else {?>
									<?php //Es una Historia. Entonces, buscar el Grupo al que pertenece
									  	$id 	= get_post_meta( $post->ID, 'Grupo_historia', true );		
										if ( $id != '' ) {
											$post_g	= get_post( $id ); 
											$titulo = $post_g->post_title;											  	
									?>											
										<a href="<?php the_permalink($post_g); ?>"><i class="fa fa-history" aria-hidden="true"></i> <?php echo $titulo; ?></a>		
									<?php } else {?>
										<i class="fa fa-history" aria-hidden="true"></i> Sin grupo asociado	
									<?php }?>
								<?php } ?>
								<p class="card-text"><?php echo $the_query->post_status; ?> </p>
																							
								<div class="more-date card-text">
									<p class="card-text"><small class="text-muted">Por: <?php the_author_meta('nickname'); ?></small></p>
									<p><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php the_author_meta('user_email'); ?>"><?php the_author_meta('user_email'); ?></a></p>
									<p><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php the_author_meta('user_url'); ?>"><?php the_author_meta('user_url'); ?></a></p>
								</div>								
									
								<div class="link-social-group pb-3">
									<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>?"><i class="fa fa-facebook-square"></i></a>
									<a href="http://twitter.com/share?text=&url=<?php the_permalink(); ?>"><i class="fa fa-twitter-square"></i></a>
									<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="fa fa-google"></i></a>
									<?php 
									$comm = 'Comentarios';
									if ( comments_open() || get_comments_number() ) :
										$comm .= '(' . get_comments_number() . ')';
									endif;?>															
									<a href="<?php the_permalink(); ?>#comments"><small class="card-link"><?php echo $comm ?></small></a>									
									<a href="<?php the_permalink(); ?>#comments" ><small class="card-link"><?php echo average_rating(); ?></small></a>
							    </div>									
							</div>
						</div>
					</div>		
		    <?php 
        		}
		    }else{
			?>
					<div class="col-md-4">
						<div class="card mt-5" style="width: 100%;">							
							<div class="card-body">
								<h5 class="card-title">Nada encontrado</h5>
								<p class="card-text">Lo siento, nada coincide con el criterio de busqueda. Por favor intente con palabras claves diferentes.</p>								
							</div>
						</div>
					</div>        		
			<?php } ?>
		</div>
	</div>	
</section>
<?php } ?>
<?php get_footer(); ?>