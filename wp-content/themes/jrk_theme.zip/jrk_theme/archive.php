<?php
/*
Template Name: Archives
*/
//get_header(); 
?>

<!DOCTYPE html>
<html>
	<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="lang" content="es" />
        <meta name="description" content="Mapas" />      
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <link rel="stylesheet" href="http://jorix.github.com/OL-Ragbag/examples/github-pages/forkme_banner.css" type="text/css">

        <title>Mapas de Grupos y/o Historias</title>
        <link rel="stylesheet" href="http://dev.openlayers.org/theme/default/style.css" type="text/css">
        <link rel="stylesheet" href="http://dev.openlayers.org/examples/style.css" type="text/css">

        <script src="http://dev.openlayers.org/OpenLayers.js"></script>
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/patches_OL-popup-autosize.js"></script>
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/lib/FeaturePopups.js"></script>
    </head>
</html>

<section>
	<br>		
	<h2 id="title" style='font-weight:bold;color:#000'>Mapas de Grupos e Historias</h2>		
	<div class="noticias-actuales">
        <p id="shortdesc">
            Muestra la informacion de los Grupos e Historias en un Mapa.
        </p>
        <div id="map" style="float:left; width: 600px; height: 500px;" class="smallmap"></div>
        <div id="divList" style="float:left; min-width: 200px; margin-left: 6px"></div>				
        <div style="clear:both" id="docs">			
            <p></p>
		</div>					
	<?php

	$args = array(
    	'post_type'  	=> 'post',
		's'  			=> get_query_var('s'), 
		'category_name' => get_query_var('categoria'),
		'author_name' 	=> get_query_var('autor'),
		'tag' 			=> get_query_var('etiqueta')
	);		
    $the_query = new WP_Query($args);						
	if ( $the_query->have_posts() ) {       
        while ( $the_query->have_posts() ) {
			$id 	= $the_query->ID;		
			$the_query->the_post();
			$titulo = get_the_title(); //$id; 
			$des 	= get_the_excerpt(); //'Colombia';
//			$the_query->the_post(); 			
			//$direccion 	= get_post_meta( $id, 'Direccion', true );		           
			$lon	= get_post_meta($id, 'Lon', true );
			$lat	= get_post_meta($id, 'Lat', true );
			if ($lon!=''){
				$a[] = array($lon, $lat);
				$b[] = array($titulo, $des);				
			}			
			
		?>
           <li>
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				<span><?php the_excerpt(); ?></span>
           </li>
    <?php 
        }
    }else{
	?>
        <h2 style='font-weight:bold;color:#000'>Nada encontrado</h2>
        <div class="alert alert-info">
          <p>Lo siento, nada coincide con el criterio de busqueda. Por favor intente con palabras claves diferentes.</p>
        </div>
	<?php } ?>
		<?php
			if (empty($a)){
				$a[] = array(-75.538, 10.4253);
				$b[] = array("Grupo 01", "Colombia");
			}
		?>			
        <div style="clear:both" id="docs">			
            <p id="desdePHP" ><?php echo jh_osm_array_string_json($a, $b); ?></p>
			<p id="desdeJS" ></p>
        </div>					
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/feature-popups-common.js"></script>
        <script src="<?php echo get_stylesheet_directory_uri(); ?>/feature-popups-external.js"></script>
		
	</div>
</section>



<?php get_footer(); ?>