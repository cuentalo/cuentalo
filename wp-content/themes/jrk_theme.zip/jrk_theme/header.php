<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo('charset');?>">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">	
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/animate.css">
	<link rel="stylesheet" href="<?php echo get_stylesheet_directory_uri(); ?>/css/font-awesome.min.css">
	<title><?php wp_title('|', true, 'right');?> <?php bloginfo('name');?></title>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<link href="https://fonts.googleapis.com/css?family=Alfa+Slab+One" rel="stylesheet">
	<?php if ( is_singular() ) wp_enqueue_script( "comment-reply" ); ?>
	<?php wp_head(); ?>
	<script type="text/javascript">
			jQuery(document).ready(function($){
				linkInterno = $('a[href^="#"]');
				linkInterno.on('click',function(e) {
				e.preventDefault();
				var href = $(this).attr('href');
				$('html, body').animate({ scrollTop : $( href ).offset().top }, 'slow');
				});

				$(window).scroll(function() {
			  if ($("#menu").offset().top > 100) {
				  $("#menu").addClass("nav-bg-1");
			  } else {
				  $("#menu").removeClass("nav-bg-1");
			  }
			});
								
			});
	</script>
</head>
<body <?php body_class(); ?>>
<?php 
				$user_msg = 'Entrar al sitio';
				global $current_user;
			    $user = $current_user->user_login;				
				if ( $user ) { 
					$user_msg = 'Hola, '.$user;	
			 	} 
?>
<a id="top"></a>
<header id="menu" class="nav-home fixed-top pt-5 d-none d-md-block d-lg-blok">
	<div class="container">
		<div class="row">
			<div class="col-2">
				<a href="http://cuentalo.org"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/logo.png" alt="" class="img-fluid logo-mg"></a>
				<a href="http://cuentalo.org/contacto"><?php echo $user_msg; ?></a>
			</div>			
			<div class="col-10">
				<div class="container-nav text-right">
					<?php wp_nav_menu(array(
					'theme_location'  => 'menu-principal',
					'container'       => 'nav',
					'container_class' => 'menu-home',
					'items_wrap'      => '<ul id="%1$s" class="menu_main">%3$s</ul>'));
					?>
				</div>			
			</div>
		</div>
	</div>
</header>

<header class="d-md-none d-lg-none">
		<nav class="navbar navbar-expand-md navbar-dark bg-dark" role="navigation">
				<div class="container">
				  <!-- Brand and toggle get grouped for better mobile display -->
				  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-controls="bs-example-navbar-collapse-1" aria-expanded="false" aria-label="Toggle navigation">
					  <span class="navbar-toggler-icon"></span>
				  </button>				  
				  <a class="navbar-brand" href="http://cuentalo.org/contacto"><?php echo $user_msg; ?></a>
				  <a href="http://cuentalo.org">Cuentalo.org</a>
					  <?php
					  wp_nav_menu( array(
						  'theme_location'    => 'menu-principal',
						  'depth'             => 2,
						  'container'         => 'div',
						  'container_class'   => 'collapse navbar-collapse',
						  'container_id'      => 'bs-example-navbar-collapse-1',
						  'menu_class'        => 'nav navbar-nav',
						  'fallback_cb'       => 'WP_Bootstrap_Navwalker::fallback',
						  'walker'            => new WP_Bootstrap_Navwalker()
					  ) );
					  ?>
				  </div>
			  </nav>
</header>


<div id="tabla-contenido"></div>	



	