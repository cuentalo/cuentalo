<?php
/*
Template Name: Agregar Historias/Grupos
*/
?>
<?php get_header(); ?>

<?php
	global $current_user;
    $user = $current_user->user_login;
	$redirect_to	= 'http://cuentalo.org/login';
	if ( !$user )  {
		wp_safe_redirect( $redirect_to );			
	}
	//Agregar una Historia al Grupo
	//Editar la Historia
	//Id del Post que deseamos editar. 
	//Cuando pid=0 o no viene: queremos agregar 
	//Si pid!=0 y viene con action=editar: queremos modificar 
	//Si pi!=0y y viene con action=ver o sin action: queremos ver
	//Datos comyunes, tanto para los grupos como para las historias
	$pid 			= 0; 
	$post_id		= 0;
	$titulo 		= '';
	$categoria		= 'Historia'; //Categoria por Default
	$imagen			= '';
	$descripcion	= '';
	$etiquetas 		= '';
	$video 			= '';
	//Datos propios de las Historias
	$grupo_historia = '';
	$narrativa 		= '';	
	$protagonistas	= '';
	//Datos propios de los grupos
	$poblacion		= '';
	$direccion 		= '';
	$accion			= 'ver'; //Por default es Ver
    if (isset($_GET['pid']) && ($_GET['pid'] != 0)) {
		$pid 			= $_GET['pid'];
	} else {
		$accion			= 'editar'; 
	}
    if (isset($_GET['grupo_his']) && ($_GET['grupo_his'] !='')) {
		$grupo_historia = $_GET['grupo_his'];
		$accion			= 'editar';  
    }
	if (isset($_GET['accion']) && ($_GET['accion'] == 'editar')) {
		$accion 		= $_GET['accion'];
	}
	if (isset($_GET['categoria']) && ($_GET['categoria'] == 'grupo')) {
		$categoria		= 'Grupo';
	}
	if ( $pid != 0 ) {
		$post	 		= get_post( $pid ); 		
	  if ($post){				
		//$post->the_post(); //No funciono 
		$post_id		= $post->ID;
		$titulo 		= $post->post_title;
		// Obtener datos del autor (contacto)
		$author_id		= $post->post_author;
		$a_nickname		= get_the_author_meta('nickname', $post->post_author);
		$a_avatar 		= get_avatar_url( $post->post_author, 32, '/images/no_images.jpg', $a_nickname );  
		$a_name			= get_the_author_meta('display_name', $post->post_author);
		$a_email		= get_the_author_meta('user_email', $post->post_author);
		$a_url			= get_the_author_meta('user_url', $post->post_author);
		//
		$categories		= get_the_category($post_id);
		if ( ! empty( $categories ) ) {
    		$categoria 	= esc_html( $categories[0]->name );   
		}
		if ( has_post_thumbnail() ) {
			$imagen = get_post_meta( $post->ID, '_thumbnail_id', true );
    		$large_image_url = wp_get_attachment_image_src( $imagen, 'large' );
    		if ( ! empty( $large_image_url[0] ) ) {
				$imagen_url =  $large_image_url[0];
			}
		}				
		//$imagen 		= get_the_post_thumbnail( $post_id, 'thumbnail'); 
		//get_the_post_thumbnail( $post_id, 'thumbnail', array( 'class' => 'alignleft' ) );
		$descripcion 	= apply_filters( 'the_content', $post->post_content ); 
		$post_tags 		= get_the_tags($post_id); 
		if ( $post_tags ) {
    		foreach( $post_tags as $tag ) {
				$tag_array[] = $tag->name;
    		}	
        	$etiquetas = implode(', ',$tag_array);
		}	
		$video 			= get_post_meta( $post_id, 'Video', true );
		$protagonistas 	= get_post_meta( $post_id, 'Protagonistas', true );
		$narrativa 		= get_post_meta( $post_id, 'Narrativa', true );		
		$poblacion 		= get_post_meta( $post_id, 'Poblacion', true );		
		$direccion 		= get_post_meta( $post_id, 'Direccion', true );		
		$lon 		= get_post_meta( $post_id, 'Lon', true );		
		$lat 		= get_post_meta( $post_id, 'Lat', true );		  
		$direccion .= ' Lon:'.$lon.' Lat:'.$lat;
		if ($grupo_historia == '') {
			$grupo_historia = get_post_meta( $post_id, 'Grupo_historia', true );		
		}	
	  }
    }
	// Variables del Form
	$editor_id 		= 'descripcion';
	$editor_id2 	= 'narrativa';
	$editor_pob 	= 'poblacion';
	$editor_dir 	= 'direccion';
   	$settings  		= array('textarea_id' => 'descripcion', 'textarea_rows' => 3); 
	$settings_narr  = array('textarea_id' => 'narrativa', 'textarea_rows' => 3); 
	$settings_pob  	= array('textarea_id' => 'poblacion', 'textarea_rows' => 3); 
	$settings_dir  	= array('textarea_id' => 'direccion', 'textarea_rows' => 3); 

	if ($accion=='editar') {
		if ($pid==0){
			$pagina_titulo		= 'Agregar '. $categoria;
			$label_submit 		= 'Enviar '. $categoria. ' para Agregar';	
		} else {
			$pagina_titulo		= 'Editar '. $categoria;
			$label_submit 		= 'Enviar Actualizacion de '. $categoria;
		}		
	} else {
		$pagina_titulo		= 'Ver '. $categoria;
		$label_submit 		= 'Error'; //No va a suceder porque no se usa en el boton
	}
	if ($categoria=='Historia'){
		$label_titulo 		= 'Titulo de la Historia';
		$small_titulo 		= 'Escriba algunas palabaras para describir el titulo de la historia';
		$small_descripcion 	= 'Detalle de la Historia. Sea muy fluido en su descripcion';
	} else {
		$label_titulo 		= 'Titulo del Grupo';
		$small_titulo 		= 'Escriba algunas palabaras para describir el titulo del Grupo';
		$small_descripcion 	= 'Detalle del Grupo. Sea muy fluido en su descripcion';
	}
?>

<div class="header-post d-none d-md-block d-lg-block"></div>

<section class="py-5 bg-gris">
<div class="container">			
	<form action="<?php echo esc_url( admin_url('admin-post.php') ); ?>" method="post" enctype="multipart/form-data">
		<h2 class="pb-1 mb-3 line-title2 font-weight-bold"><?php echo $pagina_titulo ?></h2>
		<div class="row">
			<div class="col">
			  <div class="bg-items p-5 grupo-campos card title-color-site">
				<h5 class="mb-4 font-weight-bold">Información General</h5>
				<div class="form-group">
					<?php if ($categoria=='Historia') { ?>
						<?php if ($accion!='editar') { ?>
							<?php if ( $grupo_historia != '' ) {
								$post_g	= get_post( $grupo_historia ); 
								$titulo = $post_g->post_title;											  	
							?>							
							<label for="inputEmail4 ">Esta Historia pertenece al Grupo: </label>
							<a href="<?php the_permalink($post_g); ?>"><i class="fa fa-history" aria-hidden="true"></i> <?php echo $titulo; ?></a>										
							<?php } else {?>
									<label for="inputEmail4 ">Esta Historia no esta asociado a ningun Grupo: </label>
							<?php }?>
							<?php if ( $user == $a_nickname ) { 
								$editar='http://cuentalo.org/registrar-una-historia/?pid='.$post_id.'&accion=editar'; ?>
								<label for="inputEmail4 ">Editar esta Historia: </label>
								<a href="<?php echo $editar; ?>"><i class="fa fa-plus" aria-hidden="true"></i><?php the_title(); ?></a>		
								<?php if ( $grupo_historia != '' ) {  ?>
									<label for="inputEmail4 ">Agregar otra historia al mismo grupo: </label>
									<a href="http://cuentalo.org/registrar-una-historia/?grupo_his=<?php echo $post_g->ID; ?>"><i class="fa fa-plus" aria-hidden="true"></i> Historia</a>		
								<?php } ?>			
							<?php } ?>					
						<?php } else { ?>
						<label for="inputEmail4 ">Grupo de la Historia</label>
						<input type="text" name="grupo_historia" id="grupo_historia" class="form-control" value ="<?php echo $grupo_historia ?>">
						<small class="form-text text-muted">Identifique el Grupo al que pertenece esta historia</small>
						<?php } ?>						
					<?php } else {?>
						<?php if ($accion!='editar') { ?>
						<?php 
							$id = $post->ID;
							//Calcular la cantidad de historia(s) del Grupo
							$args = array(
									'category_name' => 'historia',
									'meta_query' => array(array('key' => 'Grupo_historia', 'value' => $id))
                					);
							$gh = new WP_Query( $args );
							$c_gh = sizeof( $gh->posts );
							if ( $c_gh != 0 ) {
								$s_gh = 'Este grupo tiene ';
								if ($c_gh == 1) {
									$s_gh .= ' Una Historia asociada: ';
								} else {
									$s_gh .= $c_gh.' Historias asociadas: ';
								}	
								?>
								<label for="inputEmail4 "><?php echo $s_gh; ?></label>
								<a href="http://cuentalo.org/?s=&post_type=post&categoria=historia&grupo_historia=<?php echo $id; ?>"><i class="fa fa-history" aria-hidden="true"></i> Ver</a>
							<?php } else {?>
								<i class="fa fa-history" aria-hidden="true"></i> Sin historias	
							<?php }?>
							<?php if ( $user == $a_nickname ) { 
								$editar='http://cuentalo.org/registrar-una-historia/?pid='.$post_id.'&accion=editar'; ?>
								<label for="inputEmail4 ">Editar este grupo: </label>
								<a href="<?php echo $editar; ?>"><i class="fa fa-plus" aria-hidden="true"></i><?php the_title(); ?></a>		
								<label for="inputEmail4 ">Agregar Historia a este grupo: </label>
								<a href="http://cuentalo.org/registrar-una-historia/?grupo_his=<?php echo $id; ?>"><i class="fa fa-plus" aria-hidden="true"></i> Historia</a>		
							<?php } ?>
						<?php } ?>
					<?php } ?>															
				</div>
				<div class="form-group">
					<label for="inputEmail4 "><?php echo $label_titulo ?></label>
					<?php if ($accion!='editar') { ?>
							<div class="form-control"><?php echo $titulo; ?></div>						 
					<?php } else { ?>
						<input type="text" name="titulo" id="titulo" required class="form-control" value ="<?php echo $titulo; ?>">
					<?php } ?>
					<small class="form-text text-muted"><?php echo $small_titulo ?></small>
				</div>

				<div class="form-group">
					<label for="exampleFormControlFile1">Imagen de portada</label>
					<?php if ($accion=='editar') { ?>
						<input type="file" class="form-control-file" name="imagen" id="imagen" multiple="false">
						<small class="form-text text-muted">Seleccione una imagen o si desea cambiar la actual</small>
					<?php } ?>	
					<?php wp_nonce_field( 'imagen', 'imagen_nonce' ); ?>
					<div class="img-thumb">
						<?php if ( ($pid !=0) && (has_post_thumbnail($post_id)) ) { 
							the_post_thumbnail( 'full', array( 'class' => 'card-img-top' ) );
						} ?>
					</div>					
				</div>
				  
				<div class="form-group">
					<label for="exampleFormControlTextarea1">Descripción</label>
					<?php if ($accion!='editar') { ?>
							<div class="form-control"><?php echo $descripcion; ?></div>						 
					<?php } else { ?>
						<?php wp_editor($descripcion, $editor_id, $settings );    ?>
						<small class="form-text text-muted"><?php echo $small_descripcion ?></small>
					<?php } ?>
				</div>

				<div class="form-group">
					<label for="exampleFormControlTextarea1">Etiquetas</label>
					<?php if ($accion=='editar') { ?>
						<input type="text" name="etiquetas" class="form-control" value ="<?php echo $etiquetas ?>">
						<small class="form-text text-muted">Separar etiquetas con el signo coma ","</small>
					<?php } ?>
					<?php if ($etiquetas!='') { ?>										
						<div class="form-group">
							<i class="fa fa-tags" aria-hidden="true"></i> <?php the_tags( ' ', ' ', '<br />' ); ?>
						</div>
					<?php } ?>
				</div>
			  </div>
			</div>
			  <div class="col">
					<div class="bg-items p-5 grupo-campos card title-color-site">
						<h5 class="mb-4 font-weight-bold">Audiovisual</h5>
						<div class="form-group">
							<label for="video">Video</label>
							<?php if ($accion=='editar') { ?>								
								<input type="text" class="form-control" name="video" value ="<?php echo $video ?>">
								<small class="form-text text-muted">Coloque el enlace completo de youtube donde esta el video</small>
							<?php } ?>										
							<?php if ($video!='') { ?>										
								<div class="img-thumb">
									<?php if (strlen($video) < 12) {
										echo wp_oembed_get( 'http://www.youtube.com/watch?v=' . $video,  array('width'=>400) );
									 } else {											
										echo wp_oembed_get( $video, array('width'=>400) );
									 } ?>													
								</div>		
							<?php } ?>			
						</div>
						<?php if ($categoria=='Historia') { ?>
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Protagonistas</label>
								<?php if ($accion!='editar') { ?>
									<div class="form-control"><?php echo $protagonistas; ?></div>						 
								<?php } else { ?>					
									<input type="text" class="form-control" name="protagonistas" value ="<?php echo $protagonistas ?>">
									<small class="form-text text-muted">Separar Protagonistas con el signo coma ","</small>				
								<?php } ?>	
							</div>
							<div class="form-group">
                            	<label for="exampleFormControlTextarea1">Narativa digital</label>
								<?php if ($accion!='editar') { ?>
									<div class="form-control"><?php echo $narrativa; ?></div>						 
								<?php } else { ?>					
									<?php wp_editor($narrativa, $editor_id2, $settings_narr ); ?> 	
									<small class="form-text text-muted">Escriba aqui la narrativa de la Historia</small>
								<?php } ?>	
							</div>			
						<?php } ?>			
						<?php if ($categoria=='Grupo') { ?>
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Poblacion</label>
								<?php if ($accion!='editar') { ?>
									<div class="form-control"><?php echo $poblacion; ?></div>						 
								<?php } else { ?>					
									<?php wp_editor($poblacion, $editor_pob, $settings_pob ); ?>
									<small class="form-text text-muted">Descripcion detallada de la Poblacion a la que va dirigida este Grupo</small>	
								<?php } ?>	
							</div>
							<div class="form-group">
								<label for="exampleFormControlTextarea1">Direccion</label>
								<?php if ($accion!='editar') { ?>
									<div class="form-control"><?php echo $direccion; ?></div>		
								<?php } else { ?>					
									<?php wp_editor($direccion, $editor_dir, $settings_dir ); ?>							
									<small class="form-text text-muted">Direccion exacta de la ubicacion, y pistas sobre como llegar al lugar</small>
								<?php } ?>	
							</div>					
						<?php } ?>	

						<?php if ($accion!='editar') { ?>
							<h5 class="mb-4 font-weight-bold">Datos de Contacto</h5>
							<div class="more-date card-text">
								<img src="<?php echo esc_url($a_avatar) ?>" />
								<p class="card-text"><small class="text-muted">Por: <?php echo $a_nickname ?></small></p>
								<p><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:<?php echo $a_email ?>"><?php echo $a_email ?></a></p>
								<p><i class="fa fa-globe" aria-hidden="true"></i> <a href="<?php echo $a_url ?>"><?php echo $a_url ?></a></p>
							</div>															
							<div>
								<h5 class="mb-4 font-weight-bold">Compartir y Comentarios</h5>
								<div class="link-social-group pb-3">
									<a href="http://www.facebook.com/sharer.php?u=<?php the_permalink(); ?>?"><i class="fa fa-facebook-square"></i></a>
									<a href="http://twitter.com/share?text=&url=<?php the_permalink(); ?>"><i class="fa fa-twitter-square"></i></a>
									<a href="https://plus.google.com/share?url=<?php the_permalink(); ?>"><i class="fa fa-google"></i></a>						
								</div>
								<?php 
								if ( comments_open() || get_comments_number() ) :
									comments_template();
								endif;?>
							</div>
						<?php } ?>	
						
						<div class="form-group">
							<?php if ($accion=='editar') { ?>
								<input type="hidden" name="post_id" id="post_id" value="<?php echo $post_id ?>">
								<input type="hidden" name="categoria" id="categoria" value="<?php echo $categoria ?>">
								<input type="hidden" name="action" value="historia_form">					
								<input type="submit" class="btn-primary" value="<?php echo $label_submit ?>"/>																<button type="button" class="btn-secondary">Cancelar</button>
							<?php } else { ?>
								<button type="button">Regresar</button>
							<?php } ?>								
						</div>									
					 </div>
			  </div>
			</div>
		  </form>
	</div>
 </section>

<?php get_footer(); ?>